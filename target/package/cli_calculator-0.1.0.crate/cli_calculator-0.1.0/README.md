# rust_calculator_cli 
This project is  for laerning and implementing rust concepts.
